package com.velocity.protecteds.specifiers;

public class TestExample {

	public static void main(String[] args) {
		
		Employee employee=new Employee();
		employee.getEmployee();
	}
}
