package com.velocity.defaults.specifiers;

public class Student {

	public static void main(String[] args) {
		
		Test test=new Test();
		test.getTest(); //different class within same package only
	}
}
