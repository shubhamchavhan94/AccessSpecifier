package com.velocity.publics.specifiers;

public class Department {

	public static void main(String[] args) {
		
		Example example=new Example();
		example.getExample(); //method calling
	}
}
