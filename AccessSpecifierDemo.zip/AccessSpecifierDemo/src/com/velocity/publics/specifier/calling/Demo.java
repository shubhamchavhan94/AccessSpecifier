package com.velocity.publics.specifier.calling;

import com.velocity.publics.specifiers.Example;

public class Demo {

	public static void main(String[] args) {
		
		Example example=new Example();
		example.getExample();
	}
}
