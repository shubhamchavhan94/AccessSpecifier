package com.velocity.privates.specifiers;

//can we access private variable outside of class- No
public class Test {

	public static void main(String[] args) {

		Example example = new Example();
		//System.out.println(example.a);
	}
}
