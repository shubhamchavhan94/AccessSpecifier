package com.access.specifier.lives.examples;

public class Test {

	public static void main(String[] args) {
		
		Employee employee=new Employee();
		//employee.updateEmployee();
		//employee.addEmployee();
		//employee.deleteEmployee();
		//employee.fetchEmployee();
		//employee.deleteEmployee();
		employee.getEmployeeData();
		//employee.addEmployee();
		
	}
}
